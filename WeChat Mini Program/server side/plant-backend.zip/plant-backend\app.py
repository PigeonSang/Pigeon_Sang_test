# -*- coding: utf-8 -*-
"""
植物识别小程序后端
- GET  /models        扫描 models 目录下的 .pt 模型文件列表
- POST /predict       上传图片 + 模型文件名 + 置信度，用 YOLO 推理返回 {name, confidence, image}
启动：python app.py   (监听 0.0.0.0:8000，可用环境变量覆盖)
上线：部署到公网服务器 + HTTPS 域名，详见 README.md
"""
import os
import glob
import base64
import uuid
import tempfile
import cv2
from fastapi import FastAPI, File, UploadFile, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from ultralytics import YOLO

# 模型存放目录：本文件同级目录下的 models/，可用环境变量 PLANT_MODELS_DIR 覆盖
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODELS_DIR = os.environ.get("PLANT_MODELS_DIR", os.path.join(BASE_DIR, "models"))

app = FastAPI(title="植物识别后端")

# 允许跨域，方便小程序开发者工具 / 浏览器调试
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 已加载模型缓存：{模型文件名: YOLO 实例}，避免每次识别都重新加载 .pt
_model_cache = {}


def _model_path(name: str) -> str:
    """校验模型文件名，防止路径穿越"""
    if not name or os.path.basename(name) != name:
        raise ValueError("非法模型名")
    p = os.path.join(MODELS_DIR, name)
    if not os.path.isfile(p):
        raise ValueError(f"模型不存在：{name}")
    return p


def _load_model(name: str):
    """按文件名加载模型（带缓存）"""
    if name not in _model_cache:
        _model_cache[name] = YOLO(_model_path(name))
    return _model_cache[name]


@app.get("/models")
def list_models():
    """返回 models 目录下的 .pt 模型文件名列表"""
    if not os.path.isdir(MODELS_DIR):
        return {"models": []}
    files = sorted(glob.glob(os.path.join(MODELS_DIR, "*.pt")))
    return {"models": [os.path.basename(f) for f in files]}


@app.post("/predict")
async def predict(
    file: UploadFile = File(...),
    model: str = Form("yolov8n_plant.pt"),
    conf: float = Form(0.25),
):
    """
    接收一张图片，用指定 .pt 模型识别，返回置信度最高的类别。
    参数：
      file  - 图片文件（表单字段名 file，与小程序 wx.uploadFile 的 name 对应）
      model - 模型文件名（必须在 models 目录下）
      conf  - 置信度阈值，0~1
    返回：{"name": 类别名, "confidence": 0~1, "model": 模型名}
    """
    try:
        m_path = _model_path(model)
    except ValueError as e:
        return JSONResponse(status_code=400, content={"error": str(e)})

    # 置信度阈值范围校验，防止异常值
    try:
        conf_f = float(conf)
        conf_f = max(0.0, min(1.0, conf_f))
    except (TypeError, ValueError):
        conf_f = 0.25

    # 读取上传图片到内存
    img_bytes = await file.read()
    if not img_bytes:
        return JSONResponse(status_code=400, content={"error": "未收到图片"})

    # 保存到系统临时目录（用唯一文件名，避免多用户并发冲突；
    # 不写入代码目录，防止服务器部署目录只读/无写权限导致失败）
    tmp_path = os.path.join(tempfile.gettempdir(), f"_tmp_input_{uuid.uuid4().hex}.jpg")
    with open(tmp_path, "wb") as f:
        f.write(img_bytes)

    try:
        model_obj = _load_model(model)
        results = model_obj(tmp_path, conf=conf_f)

        # 生成标注图（YOLO 画好检测框）：results[0].plot() 返回 BGR numpy 数组
        annotated = results[0].plot()
        ok, buf = cv2.imencode(".jpg", annotated)
        image_b64 = ""
        if ok:
            image_b64 = "data:image/jpeg;base64," + base64.b64encode(buf.tobytes()).decode("utf-8")

        if len(results) == 0 or results[0].boxes is None or len(results[0].boxes) == 0:
            return {"name": "未识别到目标", "confidence": 0.0, "model": model, "image": image_b64}

        # 取置信度最高的一次检测
        boxes = results[0].boxes
        best_idx = int(boxes.conf.argmax().item())
        name = results[0].names[int(boxes.cls[best_idx].item())]
        conf_val = float(boxes.conf[best_idx].item())
        return {"name": name, "confidence": conf_val, "model": model, "image": image_b64}
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": f"推理失败：{str(e)}"})
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)


@app.get("/")
def root():
    return {"status": "ok", "models_dir": MODELS_DIR}


if __name__ == "__main__":
    import uvicorn
    # 确保 models 目录存在
    os.makedirs(MODELS_DIR, exist_ok=True)
    # 可用环境变量覆盖：PLANT_HOST / PLANT_PORT / PLANT_WORKERS
    host = os.environ.get("PLANT_HOST", "0.0.0.0")
    port = int(os.environ.get("PLANT_PORT", "8000"))
    workers = int(os.environ.get("PLANT_WORKERS", "1"))
    print(f"模型目录：{MODELS_DIR}")
    print(f"启动服务：http://{host}:{port} (workers={workers})")
    uvicorn.run(app, host=host, port=port, workers=workers)
