# 植物识别后端 · 服务器部署包

FastAPI + YOLO 植物识别服务，供微信小程序 `植辨` 调用。本目录为**可直接上传服务器的精简部署包**，已剔除本地开发 / 训练产物（爬虫、数据集脚本、训练权重、日志、虚拟环境等）。

## 包内容

| 文件 / 目录 | 说明 |
|------------|------|
| `app.py` | FastAPI 后端主程序（已修复：上传临时文件写入系统临时目录，不依赖代码目录可写） |
| `requirements.txt` | Python 依赖清单 |
| `models/yolov8n_plant.pt` | 运行用 YOLO 模型（当前默认模型） |
| `plant-backend.service` | Linux systemd 常驻服务配置（崩溃自动重启） |
| `README.md` | 本说明 |

## 服务器要求

- Linux 云服务器（有公网 IP），Python 3.9+，`pip`
- 内存建议 ≥ 2GB（YOLO 模型加载约占用 0.5~1GB）
- 正式上线需已备案域名 + HTTPS（微信小程序强制要求）

## 一、上传到服务器

本地执行（将 `plant-backend` 目录整体传到服务器）：

```bash
# 示例：上传到 /srv/plant-backend
scp -r ./plant-backend root@<服务器IP>:/srv/plant-backend
```

服务器上确保路径正确：

```bash
cd /srv/plant-backend
ls            # 应看到 app.py / requirements.txt / models / plant-backend.service
```

## 二、安装依赖并启动

```bash
cd /srv/plant-backend
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
```

先用前台方式验证能否正常启动：

```bash
.venv/bin/python app.py
# 看到 "启动服务：http://0.0.0.0:8000" 即成功，Ctrl+C 停止
```

## 三、配置 systemd 常驻（推荐，崩溃自动重启）

```bash
sudo cp plant-backend.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now plant-backend
sudo systemctl status plant-backend      # 查看运行状态 / 日志
journalctl -u plant-backend -f           # 实时查看日志
```

> `plant-backend.service` 已默认指向 `/srv/plant-backend`。若上传路径不同，请修改其中的
> `WorkingDirectory` 与 `ExecStart` 两处路径。

## 四、Nginx HTTPS 反向代理

编辑 Nginx 配置（如 `/etc/nginx/conf.d/plant.conf`）：

```nginx
server {
    listen 443 ssl;
    server_name yourdomain.com;          # 换成你的已备案域名
    ssl_certificate     /etc/ssl/cert.pem;      # Let's Encrypt / 云厂商证书
    ssl_certificate_key /etc/ssl/key.pem;

    client_max_body_size 20m;            # 允许上传较大图片

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

```bash
sudo nginx -t && sudo systemctl reload nginx
```

## 五、小程序侧配置

1. **配置服务器域名**：微信公众平台 → 开发管理 → 服务器域名，
   把 `https://yourdomain.com` 同时加入 **request 合法域名** 和 **uploadFile 合法域名**。
2. **改小程序地址**：前端 `miniprogram/app.js` 中
   `globalData.apiBase` 改为 `https://yourdomain.com`。

## 接口一览

| 接口 | 方法 | 说明 |
|------|------|------|
| `/` | GET | 健康检查，返回 `{status: "ok"}` |
| `/models` | GET | 返回 `models/` 下 `.pt` 模型文件名列表 |
| `/predict` | POST | 上传图片 + `model` + `conf`，返回 `{name, confidence, model, image}` |

`/predict` 字段：`file`(图片,表单字段名`file`)、`model`(模型文件名，默认`yolov8n_plant.pt`)、`conf`(置信度0~1，默认0.25)。
返回的 `image` 为带检测框的 base64 图，小程序 `<image>` 可直接显示。

## 可选环境变量

| 变量 | 默认 | 说明 |
|------|------|------|
| `PLANT_HOST` | `0.0.0.0` | 监听地址 |
| `PLANT_PORT` | `8000` | 端口 |
| `PLANT_WORKERS` | `1` | uvicorn 进程数（每进程独立缓存模型，多进程内存翻倍，默认 1 即可） |
| `PLANT_MODELS_DIR` | `./models` | 模型目录路径 |

## 上线注意事项

- 正式环境必须走 HTTPS（微信不校验 `http://` 明文域名）。
- 每个 `.pt` 模型首次加载占内存较大，多个模型会累加，按服务器内存控制 `models/` 内模型数量。
- 若服务器内存紧张，保持 `PLANT_WORKERS=1`；提高并发才需调大，代价是内存翻倍。
