const app = getApp()

Page({
  data: {
    models: [],          // 后端 .pt 模型文件名列表
    modelIndex: 0,       // 当前选中的模型在列表中的下标
    conf: 30,            // 置信度阈值（百分比）
    apiBase: app.globalData.apiBase,
    loadingModels: false,
    errMsg: ''
  },

  onShow() {
    // 同步接口地址（可能是启动时从缓存恢复的）到页面显示
    this.setData({ apiBase: app.globalData.apiBase })
    this.fetchModels()
    // 同步全局置信度到滑块显示
    const confPct = Math.round((app.globalData.conf || 0.3) * 100)
    this.setData({ conf: confPct })
  },

  // 从后端拉取模型列表
  fetchModels() {
    this.setData({ loadingModels: true, errMsg: '' })
    wx.request({
      url: this.data.apiBase + '/models',
      method: 'GET',
      success: (res) => {
        const list = (res.data && res.data.models) || []
        if (!list.length) {
          this.setData({ models: [], modelIndex: 0, loadingModels: false, errMsg: '后端未发现 .pt 模型文件' })
          return
        }
        // 定位当前全局模型在列表中的位置
        let idx = list.indexOf(app.globalData.model)
        if (idx < 0) idx = 0
        this.setData({ models: list, modelIndex: idx, loadingModels: false })
        // 若全局模型不在列表中，默认选第一个
        if (app.globalData.model !== list[idx]) {
          app.globalData.model = list[idx]
        }
      },
      fail: () => {
        this.setData({ loadingModels: false, errMsg: '无法连接后端，请确认服务已启动' })
      }
    })
  },

  // 选择模型
  onModelChange(e) {
    const idx = Number(e.detail.value)
    const model = this.data.models[idx]
    if (!model) return
    this.setData({ modelIndex: idx })
    app.globalData.model = model
    wx.setStorageSync('model', model)
    wx.showToast({ title: '已选择 ' + model, icon: 'none' })
  },

  // 调整置信度（百分比 -> 存全局 0~1）
  onConfChange(e) {
    const val = Number(e.detail.value)
    this.setData({ conf: val })
    app.globalData.conf = val / 100
    wx.setStorageSync('conf', app.globalData.conf)
  },

  // 修改后端地址
  onApiChange(e) {
    this.setData({ apiBase: e.detail.value })
    app.globalData.apiBase = e.detail.value
    wx.setStorageSync('apiBase', e.detail.value)
  }
})
