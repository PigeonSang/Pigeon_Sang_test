const app = getApp()

Page({
  data: {
    imagePath: '',   // 选中的图片
    loading: false,  // 是否识别中
    result: null     // 识别结果
  },

  // 拍照或从相册选图
  chooseImage() {
    if (this.data.loading) return
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['camera', 'album'],
      success: (res) => {
        const path = res.tempFiles[0].tempFilePath
        this.setData({ imagePath: path, result: null })
        this.uploadImage(path)
      }
    })
  },

  // 上传图片到后端识别（携带设置页选择的模型与置信度）
  uploadImage(path) {
    this.setData({ loading: true })
    wx.uploadFile({
      url: app.globalData.apiBase + '/predict',
      filePath: path,
      name: 'file',
      formData: {
        model: app.globalData.model,
        conf: String(app.globalData.conf)
      },
      success: (res) => {
        try {
          // 先判断 HTTP 状态码
          if (res.statusCode !== 200) {
            wx.showToast({ title: '识别失败(HTTP ' + res.statusCode + ')', icon: 'none' })
            return
          }
          const data = JSON.parse(res.data)
          if (data.error) {
            wx.showToast({ title: data.error, icon: 'none' })
            return
          }
          this.setData({
            result: {
              name: data.name || '未识别到目标',
              conf: ((data.confidence || 0) * 100).toFixed(1) + '%',
              model: data.model || app.globalData.model,
              image: data.image || ''
            }
          })
        } catch (e) {
          wx.showToast({ title: '识别响应异常', icon: 'none' })
        }
      },
      fail: () => {
        wx.showToast({ title: '识别失败，请检查后端', icon: 'none' })
      },
      complete: () => {
        this.setData({ loading: false })
      }
    })
  }
})
