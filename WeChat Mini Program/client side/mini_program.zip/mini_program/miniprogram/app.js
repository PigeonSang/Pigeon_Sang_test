App({
  onLaunch() {
    // 从本地缓存恢复用户上次的设置（后端地址 / 模型 / 置信度），否则会丢
    const apiBase = wx.getStorageSync('apiBase')
    const model = wx.getStorageSync('model')
    const conf = wx.getStorageSync('conf')
    if (apiBase) this.globalData.apiBase = apiBase
    if (model) this.globalData.model = model
    if (conf !== '') this.globalData.conf = conf
    console.log('植物识别小程序启动，apiBase=' + this.globalData.apiBase)
  },
  globalData: {
    apiBase: 'http://60.205.126.51:8000',
    model: 'yolov8n_plant.pt',
    conf: 0.25
  }
})
